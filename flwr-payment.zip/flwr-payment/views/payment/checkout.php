<div style="text-align:center; font-weight: bold;">
    <?php echo esc_html__('The payment is processed based on the address and payment amount you submitted when verifying. So please do not change this information on the transfer screen.', 'solpay'); ?>
</div><br>
<div id="solpay-woocommerce"></div>